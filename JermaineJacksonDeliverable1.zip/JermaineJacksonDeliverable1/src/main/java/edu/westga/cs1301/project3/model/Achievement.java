package edu.westga.cs1301.project3.model;

/**
 * A feat achieved, hurdle crossed, and/or challenge won
 * within a game. 
 * 
 * @author lewisb
 *
 */
public class Achievement {
	private  String gameName;
	private String message;
	
	/**
	 * Creates an Achievement for the specified game, with the
	 * given point value and message.
	 * 
	 * @precondition game !=null && message != null && !message.isBlank()
	 * @postcondition getGame()==game, getMessage()==message
	 * 
	 * @param game the game name associated with this achievement
	 * @param message the message displayed by this achievement
	 */
	public Achievement(String gameName, String message) {
		this.checkNotNull(gameName, "game can't be null");
		this.checkNotBlank(gameName, "game name can't be blank");
		
		this.checkNotNull(message, "message can't be null");
		this.checkNotBlank(message, "message can't be empty or blank");
		
		this.gameName = gameName;
		this.message = message;
	}
	
	private void checkNotNull(Object obj, String msg) {
		if (obj == null) {
			throw new IllegalArgumentException(msg);
		}
	}
	
	private void checkNotBlank(String text, String msg) {
		if (text.isBlank()) {
			throw new IllegalArgumentException(msg);
		}
	}

	/**
	 * Gets the game associated with this achievement
	 * 
	 * @return the game associated with this achievement
	 */
	public String getGameName() {
		return this.gameName;
	}

	/**
	 * Get the achievement message.
	 * 
	 * @return the achievement message.
	 */
	public String getMessage() {
		return this.message;
	}
}
