package edu.westga.cs1301.project3.model;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 * A place for gamers to hang out while waiting to join
 * a game.
 * 
 * @author lewisb
 *
 */
public class GameLobby {

	private ArrayList<GamerProfile> gamers;
	
	private String gameName;
	
	/**
	 * Creates a GameLobby for the specified game.
	 * 
	 * @precondition theGame != null && !theGame.isEmpty()
	 * @postcondition getGame()==theGame && getPlayers().isEmpty()
	 * 
	 * @param gameName the game associated with this lobby
	 */
	public GameLobby(String gameName) {
		if (gameName == null) {
			throw new IllegalArgumentException("gameName can't be null");
		}
		
		if (gameName.isEmpty()) {
			throw new IllegalArgumentException("gameName can't be empty");
		}
		
		this.gameName = gameName;
		this.gamers = new ArrayList<GamerProfile>();
	}

	/**
	 * Gets all the gamers in the lobby.
	 * 
	 * @return all the gamers in the lobby.
	 */
	public ArrayList<GamerProfile> getGamers() {
		return this.gamers;
	}

	/**
	 * Gets the name of the game associated with this lobby
	 * 
	 * @return the name of the game
	 */
	public String getGameName() {
		return this.gameName;
	}
	
	/**
	 * Adds the gamer if both of the following are true:
	 * (1) no gamer with the same user name is in the lobby
	 * (2) the gamer owns the game associated with this lobby
	 * 
	 * @precondition profile != null
	 * @postcondition the gamer is added if the above conditions are met
	 * 
	 * @param profile the profile to add
	 * @return true if the gamer was added, false otherwise
	 */
	public boolean addGamer(GamerProfile profile) {
		if (profile == null) {
			throw new IllegalArgumentException("profile can't be null");
		}
		
		if (this.hasGamerWithName(profile.getUserName())) {
			return false;
		}
		
		if (!profile.hasGame(gameName)) {
			return false;
		}
		
		this.gamers.add(profile);
		return true;
	}

	private boolean hasGamerWithName(String userName) {
		for (GamerProfile gamer : this.gamers) {
			if (gamer.getUserName().equals(userName) ) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Finds gamer with the most achievements
	 * 
	 * @param game
	 * @return
	 */
	public String findBestPlayer(GameInfo game) {
		if (this.getGamers().isEmpty()) {
	        return null;
	    }
		GamerProfile gamer = this.getGamers().get(0);
		  for (int i = 1; i < this.getGamers().size(); i++) {
		        GamerProfile otherGamer = this.getGamers().get(i);

		        if (otherGamer.totalAchievementsFor(game) > gamer.totalAchievementsFor(game)) {
		            gamer = otherGamer;
		        }
		    }
		return gamer.getUserName();
	}
}
