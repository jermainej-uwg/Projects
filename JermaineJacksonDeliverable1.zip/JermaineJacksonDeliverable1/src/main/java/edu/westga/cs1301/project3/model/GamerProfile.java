package edu.westga.cs1301.project3.model;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Represents the information about a gamer on a service like Steam, etc.
 * 
 * @author <your name here>
 *
 */
public class GamerProfile {
	
	private String userName;
	
	private ArrayList<GameInfo> gameLibrary;
	
	private ArrayList<GameInfo> achievements;

	
	/**
	 * Creates a new GamerProfile with the given user name
	 * 
	 * @precondition userName != null && !userName.isBlank()
	 * @postcondition
	 * 			getUserName()==userName &&
	 * 			getGameLibrary().isEmpty()
	 * 
	 * @param userName the screen name of the profile
	 */
	public GamerProfile(String userName) {
		this.checkNotNull(userName, "user name can't be null");
		this.checkNotBlank(userName, "user name can't be blank");
		
		this.userName = userName;
		this.gameLibrary = new ArrayList<GameInfo>();
		this.achievements = new ArrayList<GameInfo>();
	}

	private void checkNotNull(Object obj, String msg) {
		if (obj == null) {
			throw new IllegalArgumentException(msg);
		}
	}
	
	private void checkNotBlank(String text, String msg) {
		if (text.isBlank()) {
			throw new IllegalArgumentException(msg);
		}
	}

	/**
	 * Gets the user name
	 * @return the user name
	 */
	public String getUserName() {
		return this.userName;
	}

	/**
	 * Gets the game library
	 * @return the game library
	 */
	public ArrayList<GameInfo> getGameLibrary() {
		return gameLibrary;
	}
	
	/**
	 * Gets achievements for a game
	 * @return the achievements for a game
	 */
	public ArrayList<GameInfo> getAchievements() {
		return achievements;
	}
	
	/**
	 * Adds an achievement to a game if it is already in the player's library.
	 * 
	 * @precondition achievement != null
	 * @postcondition getAchievements().contains(achievement)
	 * 
	 * @param achievement the achievement to add
	 * @param game the game the achievement belongs to
	 * @return true if game is in the library, false if the game is not in the library
	 */
	public boolean addAchievements(GameInfo achievement, GameInfo game) {
		if (achievement == null) {
			throw new IllegalArgumentException("achievement cannot be null");
		}
		if (hasGame(game.getName())) {
			getAchievements().add(achievement);
			return true;
		}
		return false;
	}
	
	/**
	 * Counts the number of achievements that a gamer has for the given game.
	 * 
	 * 
	 * @param game that is associated with the achievements
	 * @return count of the total achievements for the chosen game
	 */
	public int totalAchievementsFor(GameInfo game) {
		int count = 0;
		String particularGame = game.getName();
		for (GameInfo achievement : achievements) {
			if (achievement.getName().equals(particularGame)) {
				count++;
			}
		}
		return count;
	}
	
	/**
	 * Adds a game to the player's library, IF it does not
	 * already exist.
	 * 
	 * @precondition game != null
	 * @postcondition getGameLibrary().contains(game)
	 * 
	 * @param game the game to add
	 * @result true if the game was added, false if the game
	 * 	was already in the library
	 */
	public boolean addGame(GameInfo game) {
		if (game == null) {
			throw new IllegalArgumentException("game cannot be null");
		}
		if (hasGame(game.getName())) {
			return false;
		}
		else {
			getGameLibrary().add(game);
		}
		return true;
	}
	
	/**
	 * Checks to see the player already has a given game
	 * 
	 * @precondition game != null && !game.isEmpty()
	 * @postcondition none
	 * 
	 * @param game the game to check
	 * @return true if the player has a game with the same name;
	 * 		false otherwise
	 */
	public boolean hasGame(String game) {
		checkNotNull(game, game);
		checkNotBlank(game, game);
		for (GameInfo gameInLibrary : gameLibrary) {
			if(gameInLibrary.getName().equals(game)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Gets the favorite game, meaning the one that has
	 * the most hours played.
	 * 
	 * @return the favorite game (or null if no games in library)
	 */
	public GameInfo favoriteGame() {
	    if (this.getGameLibrary().isEmpty()) {
	        return null;
	    }
	    GameInfo favGame = this.getGameLibrary().get(0);
	    for (int i = 1; i < this.getGameLibrary().size(); i++) {
	        GameInfo otherGame = this.getGameLibrary().get(i);

	        if (otherGame.getHoursPlayed() > favGame.getHoursPlayed()) {
	            favGame = otherGame;
	        }
	    }
	    return favGame;
	}
	
	/**
	 * Returns a list of games that the gamer hasn't played.
	 * 
	 * @return a list of games that the gamer hasn't played.
	 */
	public ArrayList<GameInfo> listOfUnplayedGames() {
		if (this.getGameLibrary().isEmpty()) {
	        return null;
	    }
		ArrayList<GameInfo> unplayedGames = new ArrayList<GameInfo>();
		for (GameInfo gameInLibrary : gameLibrary) {
			if(gameInLibrary.getHoursPlayed() == 0) {
				unplayedGames.add(gameInLibrary);
			}
		}
		return unplayedGames;
	}

}
