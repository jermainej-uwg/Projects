package edu.westga.cs1301.project3.model;

import java.time.LocalDate;

/**
 * Simple representation of a video game owned by a user
 * of an online service like Steam, GOG, XBox Game Pass, etc.
 * 
 * This encapsulates the game's name, the number of hours
 * the user has played it, and the most-recent date on which
 * they played it.
 * 
 * @author lewisb
 *
 */
public class GameInfo {
	private String name;
	private int hoursPlayed;
	private LocalDate lastPlayed;
	
	/**
	 * Creates a new video game item.
	 * 
	 * @precondition name != null && !name.isBlank()
	 * @postcondition
	 * 			getName()==name &&
	 * 			getHoursPlayed() == 0.0 &&
	 * 			getLastPlayed() == LocalDate.MIN
	 * 
	 * @param name the name of the game
	 */
	public GameInfo(String name) {
		this.checkNotNull(name, "name can't be null");
		this.checkNotBlank(name, "name can't be blank");
		
		this.name = name;
		this.hoursPlayed = 0;
		this.lastPlayed = LocalDate.MIN;
	}
	
	private void checkNotNull(Object obj, String msg) {
		if (obj == null) {
			throw new IllegalArgumentException(msg);
		}
	}
	
	private void checkNotBlank(String text, String msg) {
		if (text.isBlank()) {
			throw new IllegalArgumentException(msg);
		}
	}

	/**
	 * Gets the most-recent date played
	 * 
	 * @return the the most-recent date played
	 */
	public LocalDate getLastPlayed() {
		return this.lastPlayed;
	}

	/**
	 * Sets the most-recent date played
	 * 
	 * @precondition lastPlayed != null &&
	 * 		lastPlayed >= this.lastPlayed
	 * 
	 * @param lastPlayed the most-recent date played
	 */
	public void setLastPlayed(LocalDate lastPlayed) {
		this.checkNotNull(lastPlayed, "lastPlayed can't be null");
		if (this.lastPlayed.isAfter(lastPlayed)) {
			throw new IllegalArgumentException("lastPlayed must be later than the previous last played value");
		}
		this.lastPlayed = lastPlayed;
	}

	/**
	 * Gets the game's name
	 * 
	 * @return the game's name
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * Gets the number of hours played
	 * 
	 * @return the number of hours played
	 */
	public int getHoursPlayed() {
		return this.hoursPlayed;
	}
	
	/**
	 * The game gets played for the given amount of time.
	 * 
	 * @precondition hours >= 0
	 * @postcondition getHoursPlayed() += hours
	 * @param hours
	 */
	public void play(int hours) {
		if (hours < 0) {
			throw new IllegalArgumentException("hours must be >= 0");
		}
		
		this.hoursPlayed += hours;
	}
}
