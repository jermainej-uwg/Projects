package edu.westga.cs1301.project3.model;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class Test_GamerProfile_listOfUnplayedGames {

	@Test
	void testWhenGameLibraryIsEmpty() {
		GamerProfile profile = new GamerProfile("darth");

		ArrayList<GameInfo> value = profile.listOfUnplayedGames();

		assertNull(value, "value should be null");
	}
	
	@Test
	void testWhenOneGameIsInTheUnplayedGamesList() {
		GamerProfile profile = new GamerProfile("darth");
		GameInfo sith = new GameInfo("sith");
		
		profile.addGame(sith);
		int hours = 0;
		sith.play(hours);
		
		assertEquals("sith", profile.listOfUnplayedGames().get(0).getName());
	}
	
	@Test
	void testWhenMultipleGamesAreInUnplayedGamesList() {
		GamerProfile profile = new GamerProfile("darth");
		GameInfo sith = new GameInfo("sith");
		GameInfo jedi = new GameInfo("jedi");
		GameInfo mando = new GameInfo("mando");
		
		profile.addGame(sith);
		profile.addGame(jedi);
		profile.addGame(mando);
		
		int hoursSith = 0;
		int hoursJedi = 5;
		int hoursMando = 0;
		sith.play(hoursSith);
		jedi.play(hoursJedi);
		mando.play(hoursMando);

		assertEquals("sith", profile.listOfUnplayedGames().get(0).getName());
		assertEquals("mando", profile.listOfUnplayedGames().get(1).getName());
	}
	
}
