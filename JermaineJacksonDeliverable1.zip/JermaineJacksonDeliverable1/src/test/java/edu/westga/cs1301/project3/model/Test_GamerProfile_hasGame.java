package edu.westga.cs1301.project3.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


public class Test_GamerProfile_hasGame {

	@Test
	public void testShouldNotAllowNull() {
		GamerProfile profile = new GamerProfile("darth");
		assertThrows(IllegalArgumentException.class, () -> {
			profile.hasGame(null);
		});
	}
	
	
	@Test
	public void testShouldNotAllowEmptyName() {
		GamerProfile profile = new GamerProfile("darth");
		assertThrows(IllegalArgumentException.class, () -> {
			profile.hasGame(" ");
		});
	}
	
	@Test
	public void testShouldBeFalseIfNoGames() {
		// Arrange: create a GamerProfile object
		GamerProfile profile = new GamerProfile("darth");
		// Act: call hasGame on it and save the result in a variable
		Boolean noGames = profile.hasGame("Gta");
		// Assert: use an assertFalse to assert the Act result is false
		assertFalse(noGames, "No games in the library");
	}
	
	@Test
	public void testShouldBeFalseIfOnlyGameDoesNotMatch() {
		// Arrange: 
		// 1. create a GamerProfile object
		// 2. create a GameInfo object and add it to the gamer profile
		GamerProfile profile = new GamerProfile("darth");
		GameInfo info = new GameInfo("sith");
		profile.addGame(info);
		// Act: call hasGame with a name OTHER than what you used
		// in the Arrange
		Boolean noMatch = profile.hasGame("jedi");
		// Assert: use an assertFalse to assert the Act result is false
		assertFalse(noMatch, "Name doesnt match the name of the game in the library");
	}

	@Test
	public void testShouldBeTrueIfOnlyGameMatches() {
		GamerProfile profile = new GamerProfile("darth");
		GameInfo info = new GameInfo("sith");
		profile.addGame(info);
		
		Boolean match = profile.hasGame("sith");
		
		assertTrue(match, "Name does match the name of the game in the library");
		// This will be similar to the previous test
	}
	
	@Test
	public void testWhenNoGamesMatch() {
		GamerProfile profile = new GamerProfile("darth");
		GameInfo sith = new GameInfo("sith");
		GameInfo jedi = new GameInfo("jedi");
		GameInfo mando = new GameInfo("mando");
		GameInfo grogu = new GameInfo("grogu");
		
		profile.addGame(sith);
		profile.addGame(jedi);
		profile.addGame(mando);
		profile.addGame(grogu);
		
		Boolean noMatch = profile.hasGame("force");
		
		assertFalse(noMatch, "Name doesnt match the name of the game in the library");
		// This will be similar to some of the previous tests, but
		// with more than one GameInfo object
	}
	
	@Test
	public void testWhenOneOfTheGamesMatches() {
		GamerProfile profile = new GamerProfile("darth");
		GameInfo sith = new GameInfo("sith");
		GameInfo jedi = new GameInfo("jedi");
		GameInfo mando = new GameInfo("mando");
		GameInfo grogu = new GameInfo("grogu");
		
		profile.addGame(sith);
		profile.addGame(jedi);
		profile.addGame(mando);
		profile.addGame(grogu);
		
		Boolean match = profile.hasGame("mando");
		
		assertTrue(match, "Name does match the name of the game in the library");
	}
}
