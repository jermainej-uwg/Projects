package edu.westga.cs1301.project3.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Test_GamerProfile_totalAchievementsFor {

	@Test
	void testWhenThereAreNoAchievements() {
		GamerProfile profile = new GamerProfile("darth");
		GameInfo sith = new GameInfo("sith");
		int numAchievements = profile.totalAchievementsFor(sith);
		
		assertEquals(0, numAchievements);
	}
	
	@Test
	void testWhenOneAchievementMatches() {
		GamerProfile profile = new GamerProfile("darth");
		GameInfo sith = new GameInfo("sith");
		GameInfo sith2 = new GameInfo("sith");
		
		profile.addGame(sith);
		profile.addAchievements(sith, sith2);
		int numAchievements = profile.totalAchievementsFor(sith);
		
		assertEquals(1, numAchievements);
	}
	
	@Test
	void testWhenThereAreSeveralAchievements() {
		GamerProfile profile = new GamerProfile("darth");
		GameInfo sith = new GameInfo("sith");
		GameInfo sith2 = new GameInfo("sith");
		GameInfo sith3 = new GameInfo("sith");
		GameInfo sith4 = new GameInfo("sith");		
		
		profile.addGame(sith);
		
		profile.addAchievements(sith, sith2);
		profile.addAchievements(sith, sith3);
		profile.addAchievements(sith, sith4);
		int numAchievements = profile.totalAchievementsFor(sith);
		
		assertEquals(3, numAchievements);
	}

}
