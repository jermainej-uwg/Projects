package edu.westga.cs1301.project3.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Test_GamerProfile_addAchievement {

	@Test
	void testShouldNotAddNull() {
		GamerProfile profile = new GamerProfile("darth");
		
		assertThrows(IllegalArgumentException.class, () -> {
			profile.addAchievements(null, null);
		});
	}
	
	@Test
	void testShouldNotAddAchievementForGameNotInLibrary() {
		GamerProfile profile = new GamerProfile("darth");
		GameInfo noDamage = new GameInfo("Recieved no damage during a boss fight");
		GameInfo sith = new GameInfo("sith");
		
		profile.addAchievements(sith, noDamage);

		Boolean noMatch = profile.hasGame("sith");
	
		assertFalse(noMatch, "You do not own this game so you dont get the achievement");
	}
	
	@Test
	void testShouldAddAchievementForAGameInTheirLibrary() {
		GamerProfile profile = new GamerProfile("darth");
		GameInfo noDamage = new GameInfo("Recieved no damage during a boss fight");
		GameInfo sith = new GameInfo("sith");
		
		profile.addGame(sith);
		profile.addAchievements(sith, noDamage);

		Boolean hasGame = profile.hasGame("sith");
	
		assertTrue(hasGame, "You do own this game so you get the achievement");
	}
	
	@Test
	void testShouldAllowDuplicateAchievementsToBeAdded() {
		GamerProfile profile = new GamerProfile("darth");
		GameInfo noDamage = new GameInfo("Recieved no damage during a boss fight");
		GameInfo sith = new GameInfo("sith");
		
		profile.addGame(sith);
		profile.addAchievements(sith, noDamage);
		profile.addAchievements(sith, noDamage);

		Boolean hasGame = profile.hasGame("sith");
	
		assertTrue(hasGame, "You do own this game so you get the achievement");
	}

}
