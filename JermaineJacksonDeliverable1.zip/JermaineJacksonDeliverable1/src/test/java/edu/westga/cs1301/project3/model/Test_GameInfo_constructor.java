package edu.westga.cs1301.project3.model;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;



public class Test_GameInfo_constructor {

	@Test
	public void testNameShouldNotBeNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new GameInfo(null);
		});
	}

	@Test
	public void testNameShouldNotBeEmpty() {
		assertThrows(IllegalArgumentException.class, () -> {
			new GameInfo("");
		});
	}
	
	@Test
	public void testNameShouldNotBeBlank() {
		assertThrows(IllegalArgumentException.class, () -> {
			new GameInfo(" ");
		});
	}
	
	@Test
	public void testShouldCreateValidGameInfo() {
		GameInfo gameInfo = new GameInfo("Half-Life");
		assertEquals("Half-Life", gameInfo.getName());
		assertEquals(0, gameInfo.getHoursPlayed());
		assertEquals(LocalDate.MIN, gameInfo.getLastPlayed());
	}
}
