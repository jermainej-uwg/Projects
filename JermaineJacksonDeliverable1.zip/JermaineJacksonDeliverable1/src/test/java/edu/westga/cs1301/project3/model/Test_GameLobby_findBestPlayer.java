package edu.westga.cs1301.project3.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Test_GameLobby_findBestPlayer {

	@Test
	void testWhenNoPlayersAreInTheLobby() {
		GameLobby lobby = new GameLobby("Rivals");
		assertThrows(IllegalArgumentException.class, () -> {
			lobby.addGamer(null);
		});
	}
	
	@Test
	void testWhenOnePlayerIsInTheLobby() {
		GameLobby lobby = new GameLobby("Rivals");
		GamerProfile jack = new GamerProfile("jack");
		GameInfo marvelGame = new GameInfo("Rivals");
		GameInfo A = new GameInfo("achievement");
		
		jack.addGame(marvelGame);
		jack.addAchievements(A, marvelGame);
		lobby.addGamer(jack);
		
		String actual = lobby.findBestPlayer(marvelGame);
		assertEquals("jack", actual);
	}
	
	@Test
	void testWhenFirstPlayerInLobbyHasTheMostAchievements() {
		GameLobby lobby = new GameLobby("Rivals");
		GamerProfile jack = new GamerProfile("jack");
		GamerProfile jill = new GamerProfile("jill");
		GamerProfile james = new GamerProfile("james");
		GameInfo marvelGame = new GameInfo("Rivals");
		GameInfo A = new GameInfo("achievement");
		GameInfo B = new GameInfo("achievement");
		GameInfo C = new GameInfo("achievement");
		GameInfo D = new GameInfo("achievement");
		
		jack.addGame(marvelGame);
		jill.addGame(marvelGame);
		james.addGame(marvelGame);
		jack.addAchievements(A, marvelGame);
		jack.addAchievements(B, marvelGame);
		jill.addAchievements(C, marvelGame);
		james.addAchievements(D, marvelGame);
		lobby.addGamer(jack);
		lobby.addGamer(jill);
		lobby.addGamer(james);
		
		String actual = lobby.findBestPlayer(marvelGame);
		assertEquals("jack", actual);
		
	}
	
	@Test
	void testWhenLastPlayerInLobbyHasTheMostAchievements() {
		GameLobby lobby = new GameLobby("Rivals");
		GamerProfile jack = new GamerProfile("jack");
		GamerProfile jill = new GamerProfile("jill");
		GamerProfile james = new GamerProfile("james");
		GameInfo marvelGame = new GameInfo("Rivals");
		GameInfo A = new GameInfo("Rivals");
		GameInfo B = new GameInfo("Rivals");
		GameInfo C = new GameInfo("Rivals");
		GameInfo D = new GameInfo("Rivals");
		
		jack.addGame(marvelGame);
		jill.addGame(marvelGame);
		james.addGame(marvelGame);
		lobby.addGamer(jack);
		lobby.addGamer(jill);
		lobby.addGamer(james);
		jack.addAchievements(A, marvelGame);
		jill.addAchievements(B, marvelGame);
		james.addAchievements(C, marvelGame);
		james.addAchievements(D, marvelGame);
		
		String actual = lobby.findBestPlayer(marvelGame);
		assertEquals("james", actual);
	}
	
	@Test
	void testWhenMiddlePlayerInLobbyHasTheMostAchievements() {
		GameLobby lobby = new GameLobby("Rivals");
		GamerProfile jack = new GamerProfile("jack");
		GamerProfile jill = new GamerProfile("jill");
		GamerProfile james = new GamerProfile("james");
		GameInfo marvelGame = new GameInfo("Rivals");
		GameInfo A = new GameInfo("Rivals");
		GameInfo B = new GameInfo("Rivals");
		GameInfo C = new GameInfo("Rivals");
		GameInfo D = new GameInfo("Rivals");
		
		jack.addGame(marvelGame);
		jill.addGame(marvelGame);
		james.addGame(marvelGame);
		lobby.addGamer(jack);
		lobby.addGamer(jill);
		lobby.addGamer(james);
		jack.addAchievements(A, marvelGame);
		jill.addAchievements(B, marvelGame);
		jill.addAchievements(C, marvelGame);
		james.addAchievements(D, marvelGame);
		
		String actual = lobby.findBestPlayer(marvelGame);
		assertEquals("jill", actual);
	}

}
