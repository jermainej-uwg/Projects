package edu.westga.cs1301.project3.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


public class Test_Achievement_constructor {

	@Test
	public void testShouldNotAllowNullGame() {
		assertThrows(IllegalArgumentException.class, ()-> {
			new Achievement(null, "hello");
		});
	}

	@Test
	public void testShouldNotAllowPointsOneBelowMinimum() {
		assertThrows(IllegalArgumentException.class, ()-> {
			new Achievement("Minecraft", "hello");
		});
	}
	
	@Test
	public void testShouldAllowPointsAtMinimum() {
		Achievement achievement = new Achievement("Minecraft", "hello");
		assertEquals("Minecraft", achievement.getGameName());
		assertEquals("hello", achievement.getMessage());
	}
	
	@Test
	public void testShouldAllowPointsAtOneAboveMinimum() {
		Achievement achievement = new Achievement("Minecraft", "hello");
		assertEquals("Minecraft", achievement.getGameName());
		assertEquals("hello", achievement.getMessage());
	}
	
	@Test
	public void testShouldNotAllowNullMessage() {
		assertThrows(IllegalArgumentException.class, ()-> {
			new Achievement("Minecraft", null);
		});
	}
	
	@Test
	public void testShouldNotAllowEmptyMessage() {
		assertThrows(IllegalArgumentException.class, ()-> {
			new Achievement("Minecraft", "");
		});
	}
	
	@Test
	public void testShouldNotAllowBlankMessage() {
		assertThrows(IllegalArgumentException.class, ()-> {
			new Achievement("Minecraft", " ");
		});
	}
}
