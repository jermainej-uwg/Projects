package edu.westga.cs1301.project3.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


public class Test_GamerProfile_addGame {

	@Test
	public void testShouldNotAddNull() {
		// Arrange: create a GamerProfile object
		GamerProfile profile = new GamerProfile("darth");
		
		// Act & Assert: 
		assertThrows(IllegalArgumentException.class, () -> {
			profile.addGame(null);
			// call the addGame method here, with a null parameter
			// this is what we expect to throw the exception
		});
	}

	@Test
	public void testShouldAddSingleGame() {
		// Arrange:
		// 1. create a GamerProfile object
		// 2. create a GameInfo object
		GamerProfile profile = new GamerProfile("darth");
		GameInfo info = new GameInfo("sith");
		
		// Act: add the GameInfo object to the GamerProfile
		profile.addGame(info);
		// Assert:
		// (1) that the size of the game library is 1
		// (2) that the first (and only) item in the game library is
		//    the GameInfo object from the Arrange stage
		//
		// USE AN assertEquals for each of the above assertions.
		int actual = profile.getGameLibrary().size();
		int expected = 1;
		String game = new String(profile.getGameLibrary().get(0).getName());
		String firstGame = new String("sith");
		assertEquals(game, firstGame);
		assertEquals(actual, expected);
		
	}
	
	@Test
	public void testShouldAddMultipleGames() {
		GamerProfile profile = new GamerProfile("darth");
		GameInfo sith = new GameInfo("sith");
		GameInfo jedi = new GameInfo("jedi");
		GameInfo mando = new GameInfo("mando");
		
		profile.addGame(sith);
		profile.addGame(jedi);
		profile.addGame(mando);
		
		int actual = profile.getGameLibrary().size();
		int expected = 3;
		String game = new String(profile.getGameLibrary().get(0).getName());
		String firstGame = new String("sith");
		assertEquals(game, firstGame);
		assertEquals(actual, expected);
		// same as above, but add 3 games
		// make sure you have an assertion for each of the added games
	}
	
	@Test
	public void testShouldNotAddDuplicateGame() {
		GamerProfile profile = new GamerProfile("darth");
		GameInfo sith = new GameInfo("sith");
		GameInfo jedi = new GameInfo("sith");
		
		profile.addGame(sith);
		profile.addGame(jedi);
		
		Boolean noDups = profile.addGame(jedi);
		
		assertFalse(noDups, "Duplicate name of games shouldnt be added to list");
	}
}
