package edu.westga.cs1301.project3.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class Test_GameInfo_play {

	@Test
	public void testWhenHoursAreOneBelowMinimum() {
		GameInfo game = new GameInfo("Minecraft");
		assertThrows(IllegalArgumentException.class, () -> {
			game.play(-1);
		});
	}

	@Test
	public void testWhenHoursAreAtMinimum() {
		GameInfo game = new GameInfo("Minecraft");
		game.play(0);
		assertEquals(0, game.getHoursPlayed());
	}
	
	@Test
	public void testWhenHoursAreOneAboveMinimum() {
		GameInfo game = new GameInfo("Minecraft");
		game.play(1);
		assertEquals(1, game.getHoursPlayed());
	}
	
	@Test
	public void testWhenPlayedSeveralTimes() {
		GameInfo game = new GameInfo("Minecraft");
		game.play(10);
		game.play(20);
		game.play(30);
		assertEquals(60, game.getHoursPlayed());
	}
}
