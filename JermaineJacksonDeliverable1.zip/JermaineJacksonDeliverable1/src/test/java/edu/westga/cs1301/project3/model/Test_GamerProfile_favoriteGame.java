package edu.westga.cs1301.project3.model;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

class Test_GamerProfile_favoriteGame {

	@Test
	void testWhenNoGamesInLibrary() {
		// Arrange: create a GamerProfile object
		GamerProfile profile = new GamerProfile("darth");
		// Act: call favoriteGame on the profile and save its return value
		GameInfo value = profile.favoriteGame();
		// Assert: use an assertNull to assert the Act's return value is null
		assertNull(value, "value should be null");
	}

	@Test
	void testWhenOneGameInLibrary() {
		// Arrange: create a GamerProfile and add a GameInfo to it
		GamerProfile profile = new GamerProfile("darth");
		GameInfo sith = new GameInfo("sith");
		profile.addGame(sith);
		int hours = 10;
		sith.play(hours);
		// Act: call favoriteGame on the profile and save its return value
		GameInfo favGame = profile.favoriteGame();
		// Assert: use an assertEquals to assert the (only) GameInfo object you 
		// added is the favorite
		GameInfo game = favGame;
		GameInfo firstGame = sith;
		assertEquals(game, firstGame);
	}
	
	@Test
	void testWhenFirstIsFavorite() {
		GamerProfile profile = new GamerProfile("darth");
		GameInfo sith = new GameInfo("sith");
		GameInfo jedi = new GameInfo("jedi");
		GameInfo mando = new GameInfo("mando");
		
		profile.addGame(sith);
		profile.addGame(jedi);
		profile.addGame(mando);
		
		int hoursSith = 10;
		int hoursJedi = 5;
		int hoursMando= 1;
		sith.play(hoursSith);
		jedi.play(hoursJedi);
		mando.play(hoursMando);
		
		GameInfo favGame = profile.favoriteGame();
		GameInfo game = favGame;
		GameInfo firstGame = sith;
		assertEquals(game, firstGame);
		// Create three GameInfo's and add them to a GamerProfile
		// (make sure the first one has the most hours-played!)
		// Act, and then Assert the first GameInfo object is the favorite.
	}
	
	@Test
	void testWhenLastIsFavorite() {
		// this will be similar to the previous test...
		GamerProfile profile = new GamerProfile("darth");
		GameInfo sith = new GameInfo("sith");
		GameInfo jedi = new GameInfo("jedi");
		GameInfo mando = new GameInfo("mando");
		
		profile.addGame(sith);
		profile.addGame(jedi);
		profile.addGame(mando);
		
		int hoursSith = 1;
		int hoursJedi = 5;
		int hoursMando= 10;
		sith.play(hoursSith);
		jedi.play(hoursJedi);
		mando.play(hoursMando);
		
		GameInfo favGame = profile.favoriteGame();
		GameInfo game = favGame;
		GameInfo lastGame = mando;
		assertEquals(game, lastGame);
	}
	
	@Test
	void testWhenMiddleIsFavorite() {
		GamerProfile profile = new GamerProfile("darth");
		GameInfo sith = new GameInfo("sith");
		GameInfo jedi = new GameInfo("jedi");
		GameInfo mando = new GameInfo("mando");
		
		profile.addGame(sith);
		profile.addGame(jedi);
		profile.addGame(mando);
		
		int hoursSith = 1;
		int hoursJedi = 15;
		int hoursMando= 10;
		sith.play(hoursSith);
		jedi.play(hoursJedi);
		mando.play(hoursMando);
		
		GameInfo favGame = profile.favoriteGame();
		GameInfo game = favGame;
		GameInfo middleGame = jedi;
		assertEquals(game, middleGame);
	}
}
